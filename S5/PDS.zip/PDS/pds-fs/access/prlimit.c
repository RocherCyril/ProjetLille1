#include <stdio.h>
#include <limits.h>
#include <unistd.h>

int main(){
  printf("NAME_MAX: %d , PATH_MAX: %d \n",NAME_MAX,PATH_MAX);
  return 0;
}
