#   Performances des entrées/sorties

Ce répertoire correspond aux exercices de la section
[Performances des entrées/sorties](http://www.fil.univ-lille1.fr/~hym/e/pds/tp/tdfs-perfio.html).

Vous éditerez ce fichier pour qu’il contienne un compte-rendu du
travail effectué. Il pourra ainsi contenir des graphiques indiquant
les résultats de vos expériences.
