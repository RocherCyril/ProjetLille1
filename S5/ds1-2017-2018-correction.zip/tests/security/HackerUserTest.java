package security;

public class HackerUserTest {

	protected User createUser() {
		return  new HackerUser("hacker timoleon");
	}

}
