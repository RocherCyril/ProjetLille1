package security;

public class AccessDeniedException extends Exception {

}
