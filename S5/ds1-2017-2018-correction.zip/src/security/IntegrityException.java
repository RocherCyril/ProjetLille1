package security;

public class IntegrityException extends Exception {

}
