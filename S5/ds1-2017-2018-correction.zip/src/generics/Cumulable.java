package generics;

public interface Cumulable<T> {

	public T cumulate(T other);
	
}
