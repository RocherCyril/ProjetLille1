KOUCHADE Adrae, ROCHER Cyril

tout fonctionne et a était fait.

pour compiler les fichier se mettre dans le dossier src et taper la commande :


pour l'exemple1:

java -jar ../jflex-1.6.1.jar src/exemple1/exemple1.lex

pour le postfixé :

java -jar ../jflex-1.6.1.jar src/postfixees/postfixees.lex

pour le postfixé avec commentaires :

java -jar ../jflex-1.6.1.jar src/postfixees/postfixeesAvecCommentairesv2.lex




pour compiler la classe voulue :

pour l'exemple1:

javac -cp src -d bin src/exemple1/TestEx1.java

pour le postfixé et postfixé avec commentaire :

javac -cp src -d bin src/postifxees/TestPF.java

et 

javac -cp src -d bin src/postfixees/Evaluateur.java


et enfin pour tester :

pour l'exemple1:

java -cp bin exemple1.TestEx1 test.txt

pour le postfixé et postfixees avec commentaires :

java -cp bin postfixees.Evaluateur testPost.txt

