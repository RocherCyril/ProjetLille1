
class Circle {
  constructor(x,y){
    this.center=x;
    this.radius=y;
    this.restitution=1;
    this.color={r:255,g:0,b:0};
  }

  setCR(x,y){
    this.center=x;
    this.radius=u;
  }

  draw(){
    ctx.beginPath();
    ctx.strokeStyle='rgb('+this.color.r+','+this.color.g+','+this.color.b+')';
    ctx.lineWidth=2;
    ctx.arc(this.center.x,this.center.y,this.radius,0,2*Math.PI);
    ctx.stroke();
  }

  intersect(p1,p2){
    var isIntersect=false;
    var normal=new Vector(0,0);
    var position=new Vector(0,0);
    var temp1=new Vector(p1.x-this.center.x,p1.y-this.center.y);
    var temp2=new Vector(p2.x-this.center.x,p2.y-this.center.y);
    if((temp1.longueur()<=this.radius) && (temp2.longueur()>this.radius)){
      isIntersect=true;
    }
    else if ((temp1.longueur()>=this.radius) && (temp2.longueur()<this.radius)){
      isIntersect=true;
    }
    else{
      return {isIntersect};
    }
    var position = new Vector((p2.x+p1.x)/2.0,(p2.y+p1.y)/2.0);
    var x=Vector.soustract(this.center,position);
    normal = Vector.mult(x,1/x.longueur());
    return {isIntersect,normal,position};
  }

  distance(p){
    var v=Vector.soustract(p,this.center);
    if(v.longueur()>this.radius){
      return(v.longueur()-this.radius);
    }
    else{
      return(this.radius-v.longueur());
    }
  }
}


class Segment{
  constructor(a,b){
    this.a=a;
    this.b=b;
    this.restitution=1;
    this.color={r:255,g:0,b:0};
  }

  setAB(a,b){
    this.a=a;
    this.b=b;
  }

  draw(){
    ctx.beginPath();
    ctx.strokeStyle='rgb('+this.color.r+','+this.color.g+','+this.color.b+')';
    ctx.lineWidth=2;
    ctx.moveTo(this.a.x,this.a.y);
    ctx.lineTo(this.b.x,this.b.y);
    ctx.stroke();
  }

  projection(v,normal){
    return(Vector.scal(Vector.soustract(v,this.a),normal));
  }

  intersect(p1,p2){
    var isIntersect=false;
    var normal=new Vector(0,0);
    var position=this.a;
    var u=Vector.soustract(this.a,this.b);
    var x=new Vector(-u.y,u.x);
    normal = Vector.mult(x,1/x.longueur());
    var temps1 =this.projection(p1,normal);
    var temps2 =this.projection(p2,normal);
    var segP1P2=new Segment(p1,p2);
    var u2=Vector.soustract(p1,p2);
    var x2=new Vector(-u2.y,u2.x);
    var normal2 = Vector.mult(x2,1/x2.longueur());
    var temps3=segP1P2.projection(this.a,normal2);
    var temps4=segP1P2.projection(this.b,normal2);
    if((temps1>=0) && (temps2<0) && (temps3<=0) && (temps4>0)){
      isIntersect=true;
      return {isIntersect,normal,position};
    }
    else if((temps1<=0) && (temps2>0) && (temps3>=0) && (temps4<0)){
      var rapAB=segP1P2.intersect(this.a,this.b);
      if(rapAB.isIntersect){
        isIntersect=true;
        return {isIntersect,normal,position};
      }
      else{
        return{isIntersect};
      }
    }
    else{
      return{isIntersect};
    }
  }

  distance(p){
    var u=Vector.soustract(this.a,this.b);
    var x=new Vector(-u.y,u.x);
    normal = Vector.mult(x,1/x.longueur());
    var temps1=this.projection(p,normal);
    var temps2=this.projection(this.b,normal);
    if((temps1>0) && (temps2>0)){
      
    }
  }
}

class ObstacleManager{
  constructor(){
    this.all=[];
    this.nbObstacleMax=4;
  }

  draw(){
    for(var i=0;i<this.nbObstacleMax;i++){
      this.all[i].draw();
    }
  }
}
