var canvas;
var ctx; // !!! context 2D (drawing)

var engine;


window.addEventListener("load",main);

function main() {
   	canvas=document.getElementById("canvas");
  	ctx=canvas.getContext("2d");
    canvas.addEventListener('mousedown',clickAndDrag,false);
    canvas.addEventListener('mouseup',stopCliking,false);
    scene_tp3();
    engine.start();
}

function scene_tp2(){
      engine=new Engine();
      var gen1 = new GeneratorBox();
      gen1.min.setXY(300,300);
      gen1.max.setXY(300,300);
      gen1.birthRate=10;
      var gen2 = new GeneratorBox();
      gen2.min.setXY(800,300);
      gen2.max.setXY(800,300);
      gen2.birthRate=5;
      engine.particleManager.generatorList.push(gen1,gen2);
}

function scene_tp3(){
  engine=new Engine();
  var gen1 = new GeneratorBox();
  gen1.min.setXY(300,300);
  gen1.max.setXY(300,300);
  gen1.birthRate=20;
  var gen2 = new GeneratorBox();
  gen2.min.setXY(800,300);
  gen2.max.setXY(800,300);
  gen2.birthRate=30;
  engine.particleManager.generatorList.push(gen1,gen2);
  var circle1=new Circle(new Vector(300,400),60);
  circle1.restitution=0.5;
  var circle2=new Circle(new Vector(800,500),120);
  circle2.restitution=0.2;
  engine.obstacleManager.all.push(circle1,circle2);
  var segment1=new Segment(new Vector(200,700),new Vector(400,900));
  segment1.restitution=1;
  var segment2=new Segment(new Vector(600,700),new Vector(400,800));
  segment2.restitution=0;
  engine.obstacleManager.all.push(segment1,segment2);
}

function handleMouseDown(event) {
  /*
  mouseX = event.layerX-canvas.offsetLeft;
  mouseY = (event.layerY-canvas.offsetTop)-1.0;
  engine.particleManager.generatorList[0].min.setXY(mouseX,mouseY);
  engine.particleManager.generatorList[0].max.setXY(mouseX,mouseY);
  */
  engine.move();
}

function clickAndDrag(event){
  //handleMouseDown(event);
  mouseX = event.layerX-canvas.offsetLeft;
  mouseY = (event.layerY-canvas.offsetTop)-1.0;
  engine.selection(mouseX,mouseY);
  canvas.addEventListener('mousemove',handleMouseDown,false);
}

function stopCliking(event){
  canvas.removeEventListener('mousemove',handleMouseDown,false);
}
