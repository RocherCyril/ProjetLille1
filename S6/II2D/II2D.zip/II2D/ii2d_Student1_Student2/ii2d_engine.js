/**
 *
 *
 * */


var randInt=function(a,b) {
	return Math.floor(Math.random()*(b-a)+a);
}

var setAttributes=function(v,lAttrib) {
  for(var k in lAttrib) {
    v[k]=lAttrib[k];
  }
}



class Engine {
  constructor() {
    this.particleManager = new ParticleManager();
    this.time=0;
    this.deltaTime=0.1;
		this.obstacleManager = new ObstacleManager();
		this.reference=null;
  }

  draw() {
    ctx.clearRect(0,0,1000,1000);
		this.particleManager.draw();
		this.obstacleManager.draw();
  }

  updateData() {
		this.particleForce();
		this.particleMouvement();
		this.collision();
		this.particleManager.update();
  }

  loop() {
    this.time+=this.deltaTime;
    this.updateData();
    this.draw();
    window.requestAnimationFrame(this.loop.bind(this));
}

  start() {
    this.loop();
  }

	particleMouvement(){
    for(var i=0;i<this.particleManager.nbAliveMax;i++){
      if(this.particleManager.all[i].isAlive){
				this.particleManager.all[i].oldPosition.copy(this.particleManager.all[i].position);
				this.particleManager.all[i].oldVelocity.copy(this.particleManager.all[i].vitesse);
				var v1=Vector.mult(this.particleManager.all[i].force,this.deltaTime);
				var v_new=Vector.add(this.particleManager.all[i].vitesse,v1);
				this.particleManager.all[i].vitesse.copy(v_new);
				var v2=Vector.mult(this.particleManager.all[i].vitesse,this.deltaTime);
				var v3=Vector.add(this.particleManager.all[i].position,v2);
				this.particleManager.all[i].position.copy(v3);
      }
    }
  }

	particleForce(){
		for(var i=0;i<this.particleManager.nbAliveMax;i++){
      if(this.particleManager.all[i].isAlive){
				var m=1;
				var v=Vector.mult(this.particleManager.all[i].force,1/m);
				this.particleManager.all[i].force.copy(v);
			}
		}
	}

	collision(){
		for(var i=0;i<this.particleManager.nbAliveMax;i++){
      if(this.particleManager.all[i].isAlive){
				for(var o=0;o<this.obstacleManager.nbObstacleMax;o++){
					this.solveCollision(this.particleManager.all[i],this.obstacleManager.all[o]);
				}
			}
		}
	}

	solveCollision(p1,o1){
		var res=o1.intersect(p1.oldPosition,p1.position);
		if(res.isIntersect){
			this.impulse(p1,res.normal,res.position,o1.restitution);
		}
	}

	impulse(p1,ncol,pcol,restitution){
		var vnnew = Vector.mult(ncol,Vector.scal(p1.vitesse,ncol));
		var vcol =Vector.soustract(p1.vitesse,Vector.mult(vnnew,1+restitution));
		p1.vitesse.copy(vcol);
		var h=Vector.mult(ncol,Vector.scal(Vector.soustract(pcol,p1.position),ncol))
		var xcol=Vector.add(p1.position,Vector.mult(h,(1+1)));
		p1.position.copy(xcol);
	}

	selection(x,y){
		this.reference=this.obstacleManager.all[0];
		this.reference.color.r=randInt(0,255);
		this.reference.color.g=randInt(0,255);
		this.reference.color.b=randInt(0,255);
		this.reference.distance(new Vector(x,y));
	}
}
