Rocher Cyril
