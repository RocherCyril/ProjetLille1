/**
 *
 *
 *
 * */

class GeneratorBox {
  constructor() {
    this.nbBirth=0;
    this.birthRate=0.2;
    this.min=new Vector(0,0);
    this.max=new Vector(500,500);
    this.minTimeLeft=20;
    this.maxTimeLeft=150;
    this.v_min=30;
    this.v_max=-30;
  }

  initParticle(p) {
    p.position.setRandInt(this.min,this.max);
    p.color.r=randInt(0,255);
    p.color.g=randInt(0,255);
    p.color.b=randInt(0,255);
    p.color.a=1;
    p.timeAlive=randInt(this.minTimeLeft,this.maxTimeLeft);
    p.vitesse.setXY(randInt(this.v_min,this.v_max),randInt(this.v_min,this.v_max));
    p.force.copy(new Vector(0,9.81));
  }
};



/**
 *
 *
 *
 *  */
class Particle {
  constructor() {
    this.position=new Vector(0,0);
    this.color={r:0,g:0,b:0,a:1};
    this.isAlive=false;
    this.timeAlive=0;
    this.vitesse=new Vector(20,40);
    this.force=new Vector(0,9.81);
    this.oldPosition=new Vector(0,0);
    this.oldVelocity=new Vector(20,40);
  }

  draw() {
    ctx.fillStyle='rgba('+this.color.r+','+this.color.g+','+this.color.b+','+this.color.a+')';
    ctx.fillRect(this.position.x,this.position.y,8,8);
  }

};

/**
 *
 *
 *
 *
 * */


class ParticleManager {
  constructor() {
    this.all=[]
    this.nbAliveMax=5000;
    this.generatorList=[];

    for(var i=0;i<this.nbAliveMax;++i) {
      this.all.push(new Particle());
    }
  }

  update() {
    /*
    for(var i=0;i<this.nbAliveMax;i++){
      if(i<this.nbAliveMax/2){
        this.generatorList[0].initParticle(this.all[i]);
      }
      else{
        this.generatorList[1].initParticle(this.all[i]);
      }
    }
    */
    for(var i=0;i<this.generatorList.length;i++){
      this.generatorList[i].nbBirth+=this.generatorList[i].birthRate;
    }
    for(var c=0;c<this.nbAliveMax;c++){
      if(!this.all[c].isAlive){
        var j=0;
        while(!this.all[c].isAlive && j<this.generatorList.length){
          if(this.generatorList[j].nbBirth>=1){
            this.generatorList[j].initParticle(this.all[c]);
            this.all[c].isAlive=true;
            this.generatorList[j].nbBirth--;
          }
          else{
            j++;
          }
        }
      }
      else{
        this.all[c].timeAlive--;
        if(this.all[c].timeAlive<=0){
          this.all[c].isAlive=false;
          this.all[c].color.a=1;
        }
        else if(this.all[c].timeAlive<10){
          this.all[c].color.a-=0.1;
        }
      }
    }
  }

  draw() {
    for(var i=0;i<this.nbAliveMax;i++){
      if(this.all[i].isAlive){
        this.all[i].draw();
      }
    }
  }
};
